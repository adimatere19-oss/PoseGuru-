import 'package:flutter/material.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart';

void main() => runApp(const PoseGuru3DApp());

class PoseGuru3DApp extends StatelessWidget {
  const PoseGuru3DApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'PoseGuru 3D Studio',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF9652F5),
        brightness: Brightness.dark,
      ),
      scaffoldBackgroundColor: const Color(0xFF100B1D),
      useMaterial3: true,
    ),
    home: const ModelStudioPage(),
  );
}

class ModelStudioPage extends StatefulWidget {
  const ModelStudioPage({super.key});

  @override
  State<ModelStudioPage> createState() => _ModelStudioPageState();
}

class _ModelStudioPageState extends State<ModelStudioPage> {
  String selectedModel = 'male';
  String selectedPose = 'Standing';
  bool autoRotate = true;

  // Replace these demo URLs with licensed, production-ready GLB assets.
  // The current URLs are placeholders and will not render until real files are supplied.
  String get modelAsset => selectedModel == 'male'
      ? 'assets/models/male_placeholder.glb'
      : 'assets/models/female_placeholder.glb';

  static const poses = [
    'Standing',
    'Walking',
    'Sitting',
    'Looking back',
    'Hands in pockets',
    'Leaning',
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Row(children: [
        CircleAvatar(
          backgroundColor: Color(0xFF9652F5),
          child: Text('PG', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        SizedBox(width: 10),
        Text('PoseGuru 3D Studio'),
      ]),
    ),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Explore your pose reference',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 6),
        const Text(
          'Rotate the character with touch gestures. Select a pose category below.',
          style: TextStyle(color: Colors.white70),
        ),
        const SizedBox(height: 16),
        Container(
          height: 390,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: const Color(0xFF211936),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white12),
          ),
          child: ModelViewer(
            src: modelAsset,
            alt: 'PoseGuru 3D pose reference model',
            ar: false,
            autoRotate: autoRotate,
            cameraControls: true,
            disableZoom: false,
            backgroundColor: const Color(0xFF211936),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          '3D viewer integration preview. Add a rigged GLB character file to assets/models before running.',
          style: TextStyle(color: Colors.white54, fontSize: 12),
        ),
        const SizedBox(height: 18),
        const Text('Model', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'male', label: Text('Male')),
            ButtonSegment(value: 'female', label: Text('Female')),
          ],
          selected: {selectedModel},
          onSelectionChanged: (value) =>
              setState(() => selectedModel = value.first),
        ),
        const SizedBox(height: 18),
        const Text('Pose reference category',
            style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: poses.map((pose) => ChoiceChip(
            label: Text(pose),
            selected: selectedPose == pose,
            onSelected: (_) => setState(() => selectedPose = pose),
          )).toList(),
        ),
        const SizedBox(height: 10),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Auto rotate model'),
          value: autoRotate,
          onChanged: (value) => setState(() => autoRotate = value),
        ),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Text(
              'Important: selecting a pose category currently changes the UI only. '
              'Real standing, walking and sitting animations require rigged 3D characters '
              'with matching animation clips. Outfit fitting requires compatible garment '
              'meshes or a clothing simulation pipeline.',
              style: TextStyle(color: Colors.white70),
            ),
          ),
        ),
      ],
    ),
  );
}
