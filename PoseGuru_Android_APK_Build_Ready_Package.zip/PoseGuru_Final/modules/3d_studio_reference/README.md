# PoseGuru Phase 4 — 3D Model Viewer Starter

## Included
- Flutter 3D model viewer screen using `model_viewer_plus`
- Male/Female model selector
- Touch camera controls for orbit/rotation and zoom
- Auto-rotate toggle
- Pose category selector UI

## Required before it can display a character
Place licensed, optimized GLB files at:
- `flutter/assets/models/male_placeholder.glb`
- `flutter/assets/models/female_placeholder.glb`

Update `pubspec.yaml` to declare the assets if you choose local assets:

```yaml
flutter:
  uses-material-design: true
  assets:
    - assets/models/
```

The provided app references placeholder paths. No human 3D character assets are included.

## Important distinction
This phase is a 3D viewer integration scaffold, not a completed 3D character system.
- A GLB model must be supplied.
- To switch between real poses, the GLB needs a compatible rig and animation clips.
- The current pose chips only update the selected label; they do not animate the model.
- Clothing that accurately matches user-uploaded photos needs a garment asset library and a fitting/rigging pipeline.
- Live AR placement requires a separate ARKit/ARCore implementation and scene understanding. This viewer does not implement AR.

## Run
1. Install Flutter SDK.
2. Add the licensed GLB files and declare the asset directory in `pubspec.yaml`.
3. Run `flutter pub get`.
4. Run `flutter run`.

## Asset and safety checklist
Use original or properly licensed 3D assets. Optimize mesh complexity and texture sizes for mobile. Test on low- and mid-range Android/iPhone devices. Do not upload private user photos to a third-party model service without clear consent, retention rules and a privacy policy.
