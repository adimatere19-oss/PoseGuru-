# Bug report

- Device model:
- Android version:
- App build/version:
- Screen:
- Steps to reproduce:
  1.
  2.
  3.
- Expected result:
- Actual result:
- Screenshot or screen recording (avoid sharing private images):
- Backend running? (Phase 7 / Phase 8):
- Network type:
