# Integration status

| Feature | Current state |
|---|---|
| Main home and navigation | Integrated Flutter UI |
| Outfit/background selection | Gallery selection UI only |
| Outfit/background AI analysis | API scaffold included; demo response only; not wired to UI |
| Ten pose suggestions | Phase 7 rules-based API integrated |
| Favorites | Phase 8 API integrated for save/list |
| Profile/history | Basic history read screen; history write flow incomplete |
| Live camera | Camera preview integrated |
| 3D model | Placeholder only |
| AR | Not implemented; no world tracking/plane detection |
| Login | Demo identity only; no verified OTP/email |
| Ads | Not implemented |
| Localization | Not implemented end-to-end |
| Production cloud | Not deployed |
