@echo off
flutter doctor -v
if errorlevel 1 exit /b 1
flutter pub get
if errorlevel 1 exit /b 1
flutter analyze
if errorlevel 1 exit /b 1
flutter test
if errorlevel 1 exit /b 1
flutter build apk --debug
if errorlevel 1 exit /b 1
echo Debug APK: build\app\outputs\flutter-apk\app-debug.apk
