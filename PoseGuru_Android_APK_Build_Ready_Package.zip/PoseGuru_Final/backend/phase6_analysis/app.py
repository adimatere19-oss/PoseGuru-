import base64
import json
import os
from typing import Optional

from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel, Field, ValidationError

app = FastAPI(title="PoseGuru Real Vision Analysis API", version="1.2.0")

MAX_BYTES = 8 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}
AI_MODE = os.getenv("POSEGURU_AI_MODE", "demo").lower()
VISION_MODEL = os.getenv("POSEGURU_VISION_MODEL", "gpt-4.1-mini")

class OutfitAnalysis(BaseModel):
    status: str
    mode: str
    clothing_type: list[str] = Field(default_factory=list)
    dominant_colors: list[str] = Field(default_factory=list)
    style: str
    accessories: list[str] = Field(default_factory=list)
    confidence_note: str

class SceneAnalysis(BaseModel):
    status: str
    mode: str
    scene_type: str
    lighting: str
    camera_distance_hint: str
    composition_hint: str
    pose_environment_hints: list[str] = Field(default_factory=list)
    confidence_note: str

class CombinedPlan(BaseModel):
    status: str
    mode: str
    outfit: OutfitAnalysis
    scene: SceneAnalysis
    suggested_pose_direction: list[str]
    note: str

async def read_image(upload: UploadFile) -> tuple[bytes, str]:
    if upload.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, "Upload JPG, PNG or WEBP.")
    data = await upload.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "Each image must be 8 MB or smaller.")
    if not data:
        raise HTTPException(400, "Uploaded image is empty.")
    return data, upload.content_type

def data_url(data: bytes, mime: str) -> str:
    encoded = base64.b64encode(data).decode("ascii")
    return f"data:{mime};base64,{encoded}"

def demo_outfit() -> OutfitAnalysis:
    return OutfitAnalysis(
        status="demo_sample_not_image_recognition", mode="demo",
        clothing_type=["sample: casual outfit"],
        dominant_colors=["sample: neutral"], style="sample: casual",
        accessories=["sample: none detected"],
        confidence_note="Demo response only; no vision model analysed this image."
    )

def demo_scene() -> SceneAnalysis:
    return SceneAnalysis(
        status="demo_sample_not_image_recognition", mode="demo",
        scene_type="sample: outdoor location", lighting="sample: daylight",
        camera_distance_hint="Try a full-body frame with space above the head and below the feet.",
        composition_hint="Keep the subject clear of busy background objects.",
        pose_environment_hints=["sample: relaxed standing pose", "sample: slight body angle"],
        confidence_note="Demo response only; no vision model analysed this image."
    )

def extract_json(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1]
        if text.endswith("```"):
            text = text[:-3]
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end < start:
        raise ValueError("Vision model did not return a JSON object.")
    return json.loads(text[start:end + 1])

async def run_openai_vision(outfit_data, outfit_mime, scene_data, scene_mime):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(503, "OPENAI_API_KEY is not configured on the backend.")

    # Import lazily so demo mode can run without making an API request.
    from openai import AsyncOpenAI
    client = AsyncOpenAI(api_key=api_key)

    prompt = """
You are PoseGuru's photography-scene and outfit analysis component.
Analyse the provided images only for clothing attributes and photography composition.
Do not identify people or infer sensitive personal traits. Do not infer a person's
identity, age, ethnicity, religion, health, or other sensitive attributes.
If an outfit image is absent, return empty outfit arrays and style 'not provided'.
For the background image, describe visible scene category, apparent lighting,
safe camera framing, composition, and pose-environment hints. Do not invent weather
or location names that are not visually clear.
Return ONLY one valid JSON object with this exact shape:
{
  "outfit": {
    "clothing_type": ["short descriptive garment labels"],
    "dominant_colors": ["colour names"],
    "style": "casual/formal/traditional/streetwear/sporty/mixed/unknown",
    "accessories": ["visible accessories only"],
    "confidence_note": "brief uncertainty note"
  },
  "scene": {
    "scene_type": "short visible scene description",
    "lighting": "daylight/indoor/warm/backlit/low-light/mixed/unknown",
    "camera_distance_hint": "practical framing guidance",
    "composition_hint": "practical composition guidance",
    "pose_environment_hints": ["safe pose/environment hint"]
  },
  "suggested_pose_direction": ["3 concise pose direction hints"]
}
Be conservative. Say unknown when uncertain. Do not give unsafe posing advice.
"""

    content = [{"type": "input_text", "text": prompt}]
    if outfit_data is not None:
        content.append({
            "type": "input_text",
            "text": "OUTFIT REFERENCE IMAGE:"
        })
        content.append({
            "type": "input_image",
            "image_url": data_url(outfit_data, outfit_mime),
            "detail": "high"
        })
    content.append({
        "type": "input_text",
        "text": "BACKGROUND / LOCATION IMAGE:"
    })
    content.append({
        "type": "input_image",
        "image_url": data_url(scene_data, scene_mime),
        "detail": "high"
    })

    try:
        response = await client.responses.create(
            model=VISION_MODEL,
            input=[{"role": "user", "content": content}],
            max_output_tokens=900,
        )
        raw = response.output_text
        parsed = extract_json(raw)
        outfit = parsed.get("outfit", {})
        scene = parsed.get("scene", {})
        result = {
            "status": "ok",
            "mode": "live",
            "outfit": {
                "status": "analysed" if outfit_data else "not_provided",
                "mode": "live",
                "clothing_type": outfit.get("clothing_type", []),
                "dominant_colors": outfit.get("dominant_colors", []),
                "style": outfit.get("style", "unknown"),
                "accessories": outfit.get("accessories", []),
                "confidence_note": outfit.get("confidence_note", "Visual estimates; verify manually."),
            },
            "scene": {
                "status": "analysed",
                "mode": "live",
                "scene_type": scene.get("scene_type", "unknown"),
                "lighting": scene.get("lighting", "unknown"),
                "camera_distance_hint": scene.get("camera_distance_hint", "Try a full-body frame."),
                "composition_hint": scene.get("composition_hint", "Keep the subject clearly framed."),
                "pose_environment_hints": scene.get("pose_environment_hints", []),
                "confidence_note": "Visual estimates; actual lighting and scene may vary.",
            },
            "suggested_pose_direction": parsed.get("suggested_pose_direction", []),
            "note": "AI visual analysis is an estimate. Review outfit labels and choose a comfortable pose."
        }
        return CombinedPlan.model_validate(result)
    except HTTPException:
        raise
    except (ValueError, json.JSONDecodeError, ValidationError) as exc:
        raise HTTPException(502, f"Vision response could not be validated: {exc}")
    except Exception as exc:
        # Do not expose credentials or raw provider internals to the client.
        raise HTTPException(502, f"Vision provider request failed: {type(exc).__name__}")

@app.get("/health")
def health():
    live_ready = bool(os.getenv("OPENAI_API_KEY")) and AI_MODE == "live"
    return {
        "ok": True,
        "service": "poseguru-ai-analysis",
        "mode": AI_MODE,
        "vision_provider_ready": live_ready,
        "model": VISION_MODEL if live_ready else None
    }

@app.post("/analyze", response_model=CombinedPlan)
async def analyze(
    background: UploadFile = File(...),
    outfit: Optional[UploadFile] = File(default=None),
):
    scene_data, scene_mime = await read_image(background)
    outfit_data, outfit_mime = (None, None)
    if outfit is not None:
        outfit_data, outfit_mime = await read_image(outfit)

    if AI_MODE == "live":
        return await run_openai_vision(outfit_data, outfit_mime, scene_data, scene_mime)

    return CombinedPlan(
        status="demo", mode="demo",
        outfit=demo_outfit() if outfit_data else OutfitAnalysis(
            status="not_provided", mode="demo", clothing_type=[], dominant_colors=[],
            style="not provided", accessories=[],
            confidence_note="No outfit image was supplied."
        ),
        scene=demo_scene(),
        suggested_pose_direction=[
            "sample: choose a pose that does not block important background details",
            "sample: angle the body slightly toward the best available light"
        ],
        note="Demo response only; no image recognition has been performed."
    )
