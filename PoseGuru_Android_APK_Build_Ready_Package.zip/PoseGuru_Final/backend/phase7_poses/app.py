from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Optional
import random

app = FastAPI(title="PoseGuru Pose Recommendation API", version="0.7.0")

class PoseRequest(BaseModel):
    shoot_mode: str = "solo"       # solo, couple, group, selfie
    model_gender: str = "neutral"  # male, female, neutral
    outfit_style: str = "casual"
    clothing_type: List[str] = Field(default_factory=list)
    scene_type: str = "general"
    lighting: str = "daylight"
    category: str = "all"
    custom_request: Optional[str] = None
    seed: Optional[int] = None

class Pose(BaseModel):
    id: str
    title: str
    category: str
    shoot_mode: str
    camera_framing: str
    body_direction: str
    face_direction: str
    hand_placement: str
    foot_placement: str
    instruction: str
    scene_fit: str
    outfit_fit: str

class RecommendationResponse(BaseModel):
    status: str
    mode: str
    count: int
    poses: List[Pose]
    note: str

CATALOG = [
    dict(id="solo_01", title="Relaxed Full-Body Stand", category="standing", shoot_mode="solo",
         camera_framing="Full body, camera around waist-to-chest height",
         body_direction="Turn body 30 degrees from camera",
         face_direction="Look toward the lens",
         hand_placement="One hand relaxed by side, other lightly near pocket",
         foot_placement="Put weight on back foot; front foot slightly forward",
         instruction="Lengthen your posture and keep shoulders relaxed.",
         scene_fit="Works well in open streets, parks and simple backgrounds.",
         outfit_fit="Good for casual, formal and traditional outfits."),
    dict(id="solo_02", title="Look-Back Travel Pose", category="travel", shoot_mode="solo",
         camera_framing="Three-quarter or full-body frame",
         body_direction="Stand facing away, then rotate upper body slightly",
         face_direction="Look back over the near shoulder",
         hand_placement="Keep hands natural; hold a bag only if part of the outfit",
         foot_placement="One foot slightly behind the other",
         instruction="Keep the turn gentle and avoid twisting uncomfortably.",
         scene_fit="Useful when the location is an important part of the photo.",
         outfit_fit="Especially suitable for travel and layered looks."),
    dict(id="solo_03", title="Easy Walking Frame", category="walking", shoot_mode="solo",
         camera_framing="Full body with space in front of walking direction",
         body_direction="Walk diagonally across the frame",
         face_direction="Look ahead, then try a second frame toward camera",
         hand_placement="Let arms swing naturally",
         foot_placement="Capture a comfortable mid-step",
         instruction="Take slow natural steps; avoid forcing a large stride.",
         scene_fit="Best on a clear path, promenade or broad street.",
         outfit_fit="Works with casual, smart-casual and streetwear."),
    dict(id="solo_04", title="Seated Casual Pose", category="sitting", shoot_mode="solo",
         camera_framing="Three-quarter frame; camera near seated eye level",
         body_direction="Sit slightly sideways on a stable seat",
         face_direction="Turn face toward the brighter side",
         hand_placement="Rest hands loosely on thigh or armrest",
         foot_placement="Keep feet grounded; angle knees slightly",
         instruction="Sit tall without stiffening your shoulders.",
         scene_fit="Use a stable bench, step or chair; check the surface first.",
         outfit_fit="Good for casual, formal and traditional looks."),
    dict(id="solo_05", title="Wall Lean", category="leaning", shoot_mode="solo",
         camera_framing="Three-quarter or full-body frame",
         body_direction="Lean one shoulder lightly against a wall",
         face_direction="Look just beside the camera",
         hand_placement="One hand in pocket or relaxed near hip",
         foot_placement="Cross ankles lightly only if comfortable",
         instruction="Use the wall for light contact, not full body weight.",
         scene_fit="Works with clean walls and architectural backgrounds.",
         outfit_fit="Strong match for streetwear, denim and smart casual."),
    dict(id="solo_06", title="Cinematic Side Profile", category="cinematic", shoot_mode="solo",
         camera_framing="Waist-up or three-quarter frame",
         body_direction="Turn side-on to the camera",
         face_direction="Look toward the distance, not directly into lens",
         hand_placement="Keep hands low and relaxed",
         foot_placement="Stand balanced with feet comfortably apart",
         instruction="Ask the photographer to keep some negative space in your gaze direction.",
         scene_fit="Best with a visible skyline, horizon or dramatic architecture.",
         outfit_fit="Works with formal, traditional and minimalist outfits."),
    dict(id="solo_07", title="Pocket Detail Pose", category="casual", shoot_mode="solo",
         camera_framing="Three-quarter frame",
         body_direction="Angle one shoulder slightly toward camera",
         face_direction="Look at lens with a relaxed expression",
         hand_placement="Rest thumb or hand naturally at pocket opening",
         foot_placement="One foot slightly forward",
         instruction="Avoid pulling the clothing or forcing the pocket pose.",
         scene_fit="Good for uncluttered backgrounds.",
         outfit_fit="Best for trousers, jeans, jackets and casual outfits."),
    dict(id="solo_08", title="Overhead Stairs Frame", category="stylish", shoot_mode="solo",
         camera_framing="Photographer above, full-body diagonal composition",
         body_direction="Stand or sit safely on a broad step",
         face_direction="Look up toward camera",
         hand_placement="One hand lightly on railing if available",
         foot_placement="Keep both feet securely on the same stable step",
         instruction="Only use a safe, wide stair area; never pose near an edge.",
         scene_fit="Works on broad stairs with safe access.",
         outfit_fit="Good for most outfits; show footwear clearly."),
    dict(id="solo_09", title="Soft Backlit Silhouette", category="cinematic", shoot_mode="solo",
         camera_framing="Full body with bright background behind subject",
         body_direction="Turn slightly sideways",
         face_direction="Profile toward the light source",
         hand_placement="Keep arms slightly away from torso",
         foot_placement="Stand balanced, feet naturally apart",
         instruction="This creates a silhouette-style reference; facial detail may be dark.",
         scene_fit="Use only when backlighting is available.",
         outfit_fit="Outfit shape and outline matter more than small details."),
    dict(id="solo_10", title="Mirror Selfie Stance", category="selfie", shoot_mode="selfie",
         camera_framing="Mirror full-body or three-quarter frame",
         body_direction="Turn hips slightly; keep phone clear of face if desired",
         face_direction="Look at screen or mirror reflection",
         hand_placement="Hold phone steadily; free hand relaxed",
         foot_placement="One foot slightly forward",
         instruction="Clean the mirror and keep the phone lens unobstructed.",
         scene_fit="Designed for a clean mirror and enough room around you.",
         outfit_fit="Useful when showing the full outfit."),
    dict(id="couple_01", title="Side-by-Side Close Pose", category="couple", shoot_mode="couple",
         camera_framing="Waist-up or full-body, both faces visible",
         body_direction="Stand close with shoulders slightly angled inward",
         face_direction="Look at each other, then try one frame at camera",
         hand_placement="Keep hands natural; optional light hand-hold",
         foot_placement="Stand comfortably close without blocking each other",
         instruction="Keep the interaction natural and comfortable for both people.",
         scene_fit="Works in parks, streets and scenic viewpoints.",
         outfit_fit="Coordinate colours without needing identical outfits."),
    dict(id="group_01", title="Staggered Group Line", category="group", shoot_mode="group",
         camera_framing="Wide full-body frame; leave margin at both edges",
         body_direction="Arrange people in a shallow staggered line",
         face_direction="Everyone turns slightly toward the camera",
         hand_placement="Relax arms; avoid hiding faces",
         foot_placement="Keep a little space between feet and people",
         instruction="Place taller people toward the back only when everyone remains visible.",
         scene_fit="Use a wide, uncluttered area.",
         outfit_fit="Works with mixed outfits; coordinate one shared colour if desired."),
    dict(id="selfie_01", title="Arm-Length Front Camera", category="selfie", shoot_mode="selfie",
         camera_framing="Head-and-shoulders; camera slightly above eye level",
         body_direction="Turn shoulders a little rather than facing perfectly square",
         face_direction="Look at the lens",
         hand_placement="Hold phone steady with arm relaxed",
         foot_placement="Not applicable for close selfie",
         instruction="Keep the light in front of you and avoid placing it directly behind.",
         scene_fit="Best when the background is not too busy.",
         outfit_fit="Works with all outfit styles."),
]

def score_pose(p, req):
    score = 0
    mode = req.shoot_mode.lower()
    if p["shoot_mode"] == mode:
        score += 100
    elif mode == "solo" and p["shoot_mode"] == "selfie":
        score += 12
    else:
        return -100
    category = req.category.lower()
    if category not in ("all", "") and p["category"] == category:
        score += 30
    if req.scene_type.lower() not in ("", "general", "unknown"):
        scene = req.scene_type.lower()
        if any(k in scene for k in ["street", "urban", "city", "architecture"]):
            score += 8 if p["category"] in ["walking", "leaning", "stylish", "cinematic"] else 0
        if any(k in scene for k in ["park", "garden", "beach", "view", "mountain"]):
            score += 8 if p["category"] in ["travel", "standing", "cinematic"] else 0
    if req.lighting.lower() in ["backlight", "sunset", "golden hour"]:
        score += 12 if p["id"] == "solo_09" else 0
    outfit = (req.outfit_style + " " + " ".join(req.clothing_type)).lower()
    if any(k in outfit for k in ["formal", "suit", "blazer"]):
        score += 7 if p["category"] in ["standing", "cinematic", "sitting"] else 0
    if any(k in outfit for k in ["casual", "jeans", "t-shirt", "streetwear"]):
        score += 7 if p["category"] in ["casual", "walking", "leaning"] else 0
    return score

@app.get("/health")
def health():
    return {"ok": True, "service": "poseguru-pose-engine", "mode": "rules_demo"}

@app.post("/poses", response_model=RecommendationResponse)
def recommend(req: PoseRequest):
    pool = [p for p in CATALOG if p["shoot_mode"] == req.shoot_mode.lower()]
    if req.shoot_mode.lower() == "solo":
        pool += [p for p in CATALOG if p["shoot_mode"] == "selfie"]
    if not pool:
        pool = [p for p in CATALOG if p["shoot_mode"] == "solo"]

    ranked = sorted(pool, key=lambda p: score_pose(p, req), reverse=True)
    if req.seed is not None:
        rng = random.Random(req.seed)
        # Keep high-scoring options but shuffle near-ties for reproducible variety.
        top = ranked[:min(10, len(ranked))]
        rng.shuffle(top)
        ranked = top + ranked[len(top):]

    # Exactly 10 cards: if a mode has fewer curated entries, fill with safe generic
    # variations that are clearly marked as variations of the catalogue.
    chosen = ranked[:10]
    while len(chosen) < 10:
        source = ranked[(len(chosen) - len(ranked)) % len(ranked)]
        clone = dict(source)
        clone["id"] = f'{source["id"]}_variation_{len(chosen)+1}'
        clone["title"] = source["title"] + f' – Variation {len(chosen)+1-len(ranked)}'
        clone["instruction"] = source["instruction"] + " Try a slightly different camera angle or hand position."
        chosen.append(clone)

    poses = [Pose(**p) for p in chosen]
    return RecommendationResponse(
        status="ok", mode="rules_demo", count=10, poses=poses,
        note="Rule-based sample recommendations, not machine-learned AI. Choose a pose and copy it; PoseGuru does not capture or generate your final photo."
    )
