import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const PoseGuruApp());
}

class PoseGuruApp extends StatelessWidget {
  const PoseGuruApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PoseGuru',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF100D1C),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9B75FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
