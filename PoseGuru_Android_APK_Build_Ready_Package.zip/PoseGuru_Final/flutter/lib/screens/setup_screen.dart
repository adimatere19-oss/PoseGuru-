import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'poses_screen.dart';

class SetupScreen extends StatefulWidget {
  final String shootMode;
  const SetupScreen({super.key, required this.shootMode});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final picker = ImagePicker();
  XFile? outfit;
  XFile? background;
  String gender = 'female';
  String outfitStyle = 'casual';
  String scene = 'general';

  Future<void> choose(bool isOutfit) async {
    final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (image != null) setState(() => isOutfit ? outfit = image : background = image);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Photoshoot Setup')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Text('Mode: ${widget.shootMode.toUpperCase()}'),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(
        value: gender,
        decoration: const InputDecoration(labelText: 'Reference model'),
        items: const [
          DropdownMenuItem(value: 'male', child: Text('Male')),
          DropdownMenuItem(value: 'female', child: Text('Female')),
          DropdownMenuItem(value: 'neutral', child: Text('Neutral')),
        ],
        onChanged: (v) => setState(() => gender = v ?? 'female'),
      ),
      DropdownButtonFormField<String>(
        value: outfitStyle,
        decoration: const InputDecoration(labelText: 'Outfit style'),
        items: const ['casual', 'formal', 'traditional', 'streetwear', 'travel']
          .map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: (v) => setState(() => outfitStyle = v ?? 'casual'),
      ),
      TextFormField(
        initialValue: scene,
        decoration: const InputDecoration(labelText: 'Location / scene type'),
        onChanged: (v) => scene = v,
      ),
      const SizedBox(height: 16),
      _UploadTile(title: 'Upload outfit reference', file: outfit, onTap: () => choose(true)),
      _UploadTile(title: 'Upload background / location', file: background, onTap: () => choose(false)),
      const SizedBox(height: 20),
      FilledButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => PosesScreen(
            mode: widget.shootMode, gender: gender, outfitStyle: outfitStyle,
            scene: scene, outfitPath: outfit?.path, backgroundPath: background?.path,
          ),
        )),
        child: const Text('Show 10 Pose Ideas'),
      ),
      const SizedBox(height: 8),
      const Text('Image analysis is not automatically run by this screen yet. The selected images stay on this device in this starter.',
        style: TextStyle(color: Colors.white60, fontSize: 12)),
    ]),
  );
}

class _UploadTile extends StatelessWidget {
  final String title;
  final XFile? file;
  final VoidCallback onTap;
  const _UploadTile({required this.title, required this.file, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: const Icon(Icons.add_photo_alternate_outlined),
      title: Text(title),
      subtitle: Text(file?.name ?? 'No image selected'),
      trailing: const Icon(Icons.upload),
      onTap: onTap,
    ),
  );
}
