import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class LiveGuideScreen extends StatefulWidget {
  const LiveGuideScreen({super.key});
  @override
  State<LiveGuideScreen> createState() => _LiveGuideScreenState();
}

class _LiveGuideScreenState extends State<LiveGuideScreen> {
  CameraController? controller;
  String? error;
  bool loading = true;

  @override
  void initState() { super.initState(); initCamera(); }

  Future<void> initCamera() async {
    try {
      final permission = await Permission.camera.request();
      if (!permission.isGranted) throw Exception('Camera permission not granted.');
      final cameras = await availableCameras();
      if (cameras.isEmpty) throw Exception('No camera available.');
      final back = cameras.where((c) => c.lensDirection == CameraLensDirection.back);
      final selected = back.isNotEmpty ? back.first : cameras.first;
      final c = CameraController(selected, ResolutionPreset.high, enableAudio: false);
      await c.initialize();
      if (!mounted) { await c.dispose(); return; }
      setState(() { controller = c; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  void dispose() { controller?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Live Pose Guide')),
    body: loading ? const Center(child: CircularProgressIndicator())
      : error != null ? Center(child: Padding(
          padding: const EdgeInsets.all(24), child: Text('$error\n\nThis screen only previews the camera; AR model tracking is not connected.', textAlign: TextAlign.center)))
      : Stack(fit: StackFit.expand, children: [
          CameraPreview(controller!),
          Center(child: Container(
            width: 190, height: 340,
            decoration: BoxDecoration(
              color: Colors.deepPurple.withOpacity(0.18),
              border: Border.all(color: Colors.white70, width: 2),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.accessibility_new, size: 100),
              Text('3D / AR MODEL PLACEHOLDER', textAlign: TextAlign.center),
            ]),
          )),
          const Positioned(left: 16, right: 16, bottom: 24, child: Text(
            'Copy the reference pose. PoseGuru does not capture your photo. Real AR tracking is not connected.',
            textAlign: TextAlign.center, style: TextStyle(backgroundColor: Colors.black54),
          )),
        ]),
  );
}
