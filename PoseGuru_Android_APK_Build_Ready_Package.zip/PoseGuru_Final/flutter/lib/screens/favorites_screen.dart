import 'package:flutter/material.dart';
import '../services/profile_service.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  final service = ProfileService();
  late Future<List<Map<String, dynamic>>> future;
  @override
  void initState() { super.initState(); future = service.favorites(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Favourite Poses')),
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Text('Could not load favourites. Start Phase 8 API.\n${snapshot.error}', textAlign: TextAlign.center));
        final items = snapshot.data ?? [];
        if (items.isEmpty) return const Center(child: Text('No favourite poses saved yet.'));
        return ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, i) => ListTile(
            leading: const Icon(Icons.bookmark, color: Color(0xFFC6AEFF)),
            title: Text(items[i]['title'] ?? items[i]['pose_id']),
            subtitle: Text(items[i]['category_name'] ?? 'My Favorites'),
          ),
        );
      },
    ),
  );
}
