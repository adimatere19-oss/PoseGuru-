import 'package:flutter/material.dart';
import '../services/pose_service.dart';
import '../services/profile_service.dart';

class PosesScreen extends StatefulWidget {
  final String mode, gender, outfitStyle, scene;
  final String? outfitPath, backgroundPath;
  const PosesScreen({super.key, required this.mode, required this.gender,
    required this.outfitStyle, required this.scene, this.outfitPath, this.backgroundPath});

  @override
  State<PosesScreen> createState() => _PosesScreenState();
}

class _PosesScreenState extends State<PosesScreen> {
  final service = PoseService();
  final profile = ProfileService();
  late Future<List<Map<String, dynamic>>> future;
  int current = 0;

  @override
  void initState() {
    super.initState();
    future = load();
  }

  Future<List<Map<String, dynamic>>> load() => service.recommend(
    mode: widget.mode, gender: widget.gender, outfitStyle: widget.outfitStyle,
    clothing: const [], scene: widget.scene, lighting: 'daylight',
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Your Pose Ideas')),
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text('Could not load poses. Check that the Phase 7 API is running.\n${snapshot.error}', textAlign: TextAlign.center),
        ));
        final poses = snapshot.data ?? [];
        if (poses.isEmpty) return const Center(child: Text('No poses available.'));
        final pose = poses[current % poses.length];
        return ListView(padding: const EdgeInsets.all(18), children: [
          Container(
            height: 190,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [Color(0xFF5C3AA0), Color(0xFF21183D)]),
            ),
            child: const Center(child: Icon(Icons.accessibility_new, size: 100, color: Colors.white)),
          ),
          const SizedBox(height: 16),
          Text('${current + 1} / ${poses.length}', style: const TextStyle(color: Colors.white60)),
          Text(pose['title'] ?? 'Pose', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _Detail(label: 'Camera framing', value: pose['camera_framing']),
          _Detail(label: 'Body direction', value: pose['body_direction']),
          _Detail(label: 'Face direction', value: pose['face_direction']),
          _Detail(label: 'Hand placement', value: pose['hand_placement']),
          _Detail(label: 'Foot placement', value: pose['foot_placement']),
          _Detail(label: 'Instruction', value: pose['instruction']),
          const SizedBox(height: 16),
          Row(children: [
            OutlinedButton(onPressed: () => setState(() => current = (current - 1 + poses.length) % poses.length), child: const Text('Previous')),
            const Spacer(),
            OutlinedButton(onPressed: () => setState(() => current = (current + 1) % poses.length), child: const Text('Next')),
          ]),
          FilledButton.icon(
            onPressed: () async {
              try {
                await profile.addFavorite(pose['id'], pose['title'] ?? 'Pose');
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved to favourites')));
              } catch (e) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
              }
            },
            icon: const Icon(Icons.bookmark_add), label: const Text('Save to Favourites'),
          ),
          const SizedBox(height: 8),
          const Text('The model illustration is a placeholder. Connect licensed 3D pose assets to display the actual reference model.',
            style: TextStyle(color: Colors.white60, fontSize: 12)),
        ]);
      },
    ),
  );
}

class _Detail extends StatelessWidget {
  final String label;
  final dynamic value;
  const _Detail({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: Color(0xFFC6AEFF), fontWeight: FontWeight.bold)),
      const SizedBox(height: 3),
      Text((value ?? 'Not provided').toString()),
    ]),
  );
}
