import 'package:flutter/material.dart';
import '../services/profile_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final service = ProfileService();
  late Future<List<Map<String, dynamic>>> future;
  @override
  void initState() { super.initState(); future = service.history(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Profile')),
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Text('Profile history is unavailable. Start Phase 8 API.\n${snapshot.error}', textAlign: TextAlign.center));
        final items = snapshot.data ?? [];
        return ListView(padding: const EdgeInsets.all(18), children: [
          const CircleAvatar(radius: 38, child: Icon(Icons.person, size: 42)),
          const SizedBox(height: 12),
          const Center(child: Text('PoseGuru Demo Profile', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          const SizedBox(height: 22),
          const Text('Recent Photoshoot History', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          if (items.isEmpty) const Padding(
            padding: EdgeInsets.only(top: 16),
            child: Text('No shoot history yet. History recording will be connected in a later integration step.'),
          ),
          ...items.map((x) => ListTile(
            leading: const Icon(Icons.history),
            title: Text(x['pose_title']?.toString().isNotEmpty == true ? x['pose_title'] : 'Photoshoot'),
            subtitle: Text('${x['shoot_mode'] ?? 'solo'} • ${x['background_label'] ?? ''}'),
          )),
          const SizedBox(height: 20),
          const Text('Demo profile only. Verified mobile/email login and full profile editing are not connected.',
            style: TextStyle(color: Colors.white60, fontSize: 12)),
        ]);
      },
    ),
  );
}
