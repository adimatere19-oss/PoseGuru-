import 'package:flutter/material.dart';
import 'setup_screen.dart';
import 'favorites_screen.dart';
import 'profile_screen.dart';
import 'live_guide_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Solo Photoshoot', Icons.person, 'solo'),
      ('Couple Photoshoot', Icons.favorite, 'couple'),
      ('Group Photoshoot', Icons.groups, 'group'),
      ('Selfie Guide', Icons.camera_front, 'selfie'),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('PoseGuru', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Profile',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen())),
            icon: const Icon(Icons.account_circle_outlined),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(colors: [Color(0xFF55339A), Color(0xFF21183D)]),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Your Personal AI Photography Guide', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('You choose the place. PoseGuru guides your pose.'),
            ]),
          ),
          const SizedBox(height: 22),
          const Text('Start your photoshoot', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.35,
            ),
            itemBuilder: (context, index) {
              final item = items[index];
              return _HomeTile(
                title: item.$1, icon: item.$2,
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => SetupScreen(shootMode: item.$3),
                )),
              );
            },
          ),
          const SizedBox(height: 12),
          _HomeTile(
            title: 'Live Camera Pose Guide', icon: Icons.view_in_ar,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LiveGuideScreen())),
          ),
          const SizedBox(height: 12),
          _HomeTile(
            title: 'My Favourite Poses', icon: Icons.bookmark,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FavoritesScreen())),
          ),
          const SizedBox(height: 24),
          const Text('PoseGuru is a pose reference guide. It does not take or generate your final photo.',
            style: TextStyle(color: Colors.white60, fontSize: 12)),
        ],
      ),
    );
  }
}

class _HomeTile extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  const _HomeTile({required this.title, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF211B32),
    child: InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Icon(icon, size: 30, color: const Color(0xFFC6AEFF)),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600))),
          const Icon(Icons.chevron_right),
        ]),
      ),
    ),
  );
}
