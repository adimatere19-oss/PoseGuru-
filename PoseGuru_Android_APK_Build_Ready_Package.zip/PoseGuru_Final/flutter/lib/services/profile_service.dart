import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class ProfileService {
  Future<List<Map<String, dynamic>>> favorites() async {
    final r = await http.get(Uri.parse(
      '${ApiConfig.profileApi}/favorites/poses/${ApiConfig.demoUserId}',
    ));
    _check(r);
    return (jsonDecode(r.body) as List).cast<Map<String, dynamic>>();
  }

  Future<void> addFavorite(String poseId, String title) async {
    final r = await http.post(
      Uri.parse('${ApiConfig.profileApi}/favorites/poses'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'user_id': ApiConfig.demoUserId,
        'pose_id': poseId,
        'title': title,
        'category_name': 'My Favorites',
      }),
    );
    _check(r);
  }

  Future<List<Map<String, dynamic>>> history() async {
    final r = await http.get(Uri.parse(
      '${ApiConfig.profileApi}/history/${ApiConfig.demoUserId}',
    ));
    _check(r);
    return (jsonDecode(r.body) as List).cast<Map<String, dynamic>>();
  }

  void _check(http.Response r) {
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Profile API ${r.statusCode}: ${r.body}');
    }
  }
}
