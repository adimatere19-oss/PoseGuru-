class ApiConfig {
  // Android emulator can reach host machine via 10.0.2.2.
  // For a physical phone, replace with your computer's LAN IP.
  static const String poseApi = 'http://10.0.2.2:8001';
  static const String profileApi = 'http://10.0.2.2:8002';
  static const String analysisApi = 'http://10.0.2.2:8003';

  // Demo-only identity. Replace with a server-verified authenticated session.
  static const String demoUserId = 'poseguru-demo-user';
}
