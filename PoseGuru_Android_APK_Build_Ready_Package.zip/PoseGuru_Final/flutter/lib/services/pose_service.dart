import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class PoseService {
  Future<List<Map<String, dynamic>>> recommend({
    required String mode,
    required String gender,
    required String outfitStyle,
    required List<String> clothing,
    required String scene,
    required String lighting,
  }) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.poseApi}/poses'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'shoot_mode': mode,
        'model_gender': gender,
        'outfit_style': outfitStyle,
        'clothing_type': clothing,
        'scene_type': scene,
        'lighting': lighting,
        'category': 'all',
      }),
    ).timeout(const Duration(seconds: 30));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Pose API ${response.statusCode}: ${response.body}');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (data['poses'] as List).cast<Map<String, dynamic>>();
  }
}
